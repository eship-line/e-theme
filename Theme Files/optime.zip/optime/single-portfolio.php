<?php
/**
 * The template for displaying all single service
 *
 * @package Optime
 */
get_header();
get_template_part( 'template-parts/content-portfolio/content');
get_footer();
