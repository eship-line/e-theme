<?php
/**
 * The template for displaying all single career
 *
 * @package Optime
 */
get_header();
get_template_part( 'template-parts/content-service/content');
get_footer();
